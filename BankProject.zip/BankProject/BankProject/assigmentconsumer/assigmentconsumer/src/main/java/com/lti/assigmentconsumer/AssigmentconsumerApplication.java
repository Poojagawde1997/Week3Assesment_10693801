package com.lti.assigmentconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
//import org.springframework.context.ApplicationContext;

//import com.lti.assigmentconsumer.Controller.ConsumerController;

@SpringBootApplication
@EnableDiscoveryClient
public class AssigmentconsumerApplication {

	public static void main(String[] args) {
		
		//ApplicationContext ctx=
		SpringApplication.run(AssigmentconsumerApplication.class, args);
		/*ConsumerController consumercontroller=ctx.getBean(ConsumerController.class);
		System.out.println(consumercontroller);
		consumercontroller.getBank();*/
		
	}

}
