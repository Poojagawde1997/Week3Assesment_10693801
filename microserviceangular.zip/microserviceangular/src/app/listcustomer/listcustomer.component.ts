import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';

import { BankserService } from '../bankser.service';


@Component({
  selector: 'app-listcustomer',
  templateUrl: './listcustomer.component.html',
  styleUrls: ['./listcustomer.component.css']
})
export class ListcustomerComponent implements OnInit {
  
  bank:any;
  constructor(private bankservice:BankserService,private route:Router) { }

  ngOnInit() {
    this.onreloadData();
  }

  onreloadData(){
    this.bank=this.bankservice.getcustomer();
  }

  deleteCustomer(id:any){
    this.bankservice.deletecustomer(id).subscribe(data => {
      console.log(data);
      this.onreloadData();
    },
    error => console.log(error));

  }

  updateCustomer(id:any){
    this.route.navigate(['updatecustomer',id]);
  }

  customerDetail(id:any){
    this.route.navigate(['customerdetails',id]);
  }

}
