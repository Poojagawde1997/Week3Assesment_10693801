import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Bankmodule } from '../Bankmodule';
import { BankserService } from '../bankser.service';
import {FormControl, FormGroup, Validators} from "@angular/forms";

@Component({
  selector: 'app-updatecustomer',
  templateUrl: './updatecustomer.component.html',
  styleUrls: ['./updatecustomer.component.css']
})
export class UpdatecustomerComponent implements OnInit {

  id:any;
  customer:any;
  updatecust!:FormGroup;


  constructor(private bankservice:BankserService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
    
    
    this.id=this.route.snapshot.params['id'];
    this.updatecust= new FormGroup({
      name:new FormControl(['',Validators.required]),
      age:new FormControl(['',Validators.required]),
      address:new FormControl(['',Validators.required]),
      typeofacc:new FormControl(['',Validators.required])
    })
    this.bankservice.getcustomerbyid(this.id).subscribe(data=>{
      console.log(data)
      this.customer=data;
    },error=>console.log(error));
    this.customer= new Bankmodule();
    
  }

  onSubmit(){
    this.updateCustomer();
  }

  updateCustomer(){
    this.bankservice.updatecustomer(this.id,this.updatecust.value).subscribe(data=>{
      console.log(data)
      this.customer=new Bankmodule();
      this.gotoList();

    },error => console.log(error))
  }

  gotoList(){
    this.router.navigate(['/bankcustomer']);
  }

}
