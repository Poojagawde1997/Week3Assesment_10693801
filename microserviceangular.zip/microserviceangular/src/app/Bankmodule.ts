export class Bankmodule{
    id:any;
    name:any;
    age:any;
    address:any;
    typeofacc:any;
}