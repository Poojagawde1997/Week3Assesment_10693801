package com.lti.assigmentconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssigmentconsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
